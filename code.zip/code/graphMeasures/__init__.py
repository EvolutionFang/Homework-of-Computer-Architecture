import warnings

from .features_for_any_graph import FeatureCalculator
from .features_meta import features_meta
from .features_meta import accelerated_features_meta

warnings.filterwarnings("ignore")
