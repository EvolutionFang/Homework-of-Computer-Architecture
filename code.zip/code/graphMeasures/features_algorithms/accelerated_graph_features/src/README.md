# Source files for the project

## arch
Files for the general architecture of the library

## features
Feature calculators

## includes
include files for the project
