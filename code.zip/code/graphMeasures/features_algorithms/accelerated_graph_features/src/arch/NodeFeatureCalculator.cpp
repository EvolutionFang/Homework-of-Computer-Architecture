#include "stdafx.h"
#include "NodeFeatureCalculator.h"


template<class T>
NodeFeatureCalculator<T>::NodeFeatureCalculator()
{
}

template<class T>
NodeFeatureCalculator<T>::~NodeFeatureCalculator()
{
}
