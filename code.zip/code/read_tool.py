import pickle

# 指定文件路径
file_path = "vertices_mapping.pkl"

# 读取.pkl文件
with open(file_path, "rb") as file:
    loaded_data = pickle.load(file)

# 现在loaded_data中包含了.pkl文件中的数据
print(loaded_data)

